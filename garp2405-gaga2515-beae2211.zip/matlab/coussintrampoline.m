clear
clc
ma = 80;
mb = 8;
e=0.8;
van = 22,5  / 3600/1000
vbn = -1;

p = [3000 -863.28 -4316.4];
r = roots(p)
display(r)