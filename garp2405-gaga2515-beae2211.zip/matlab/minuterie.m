clear clc

  G1 = (80*22.5+8*-3.6)/88
  G1Ms = G1/3.6
  
  %G2
   vafinal = (-20.88 +221.4)/11
   vaG2finalMs = vafinal/3.6

